# SKYJO Action V12 – Regressionstests für Spezialfähigkeiten

- Alle neun Spezialkarten werden durch automatisierte Tests gegen den **tatsächlichen** `playAction`-Code geprüft.
- Zusätzlich geprüft: doppelter Extrazug, Verteidigungs-Extrazug, Ablage/Reaktivierung und Schutz gegen unberechtigte bzw. veraltete Kartenauswahl.
- Alle 35 Logikteile werden mit SHA-256 kontrolliert und als vollständiges JavaScript syntaktisch geprüft.
- **Wichtig:** Die Spielregeln und Serverkommunikation sind gegenüber V11 unverändert. Tests der Einstiegsfunktionen sind keine vollständigen End-to-End-Tests der neun Fähigkeiten.
- V12-Loader erwartet Manifest-Version 12; GitHub/Render unverändert. Browser- und Multiplayer-Tests weiterhin erforderlich.

Test: `node tests/skyjo-v12-abilities.test.cjs`
