# SKYJO V10 – Funktionsmodul Aktionskarten

Neues Modul: `Skyjo/skyjo_action-actions.js` enthält die Definitionen der neun Spezialkarten. Die Spiellogik referenziert den Katalog; die Spielfunktionen und Regeln wurden nicht verändert.

Geprüft: alle neun Kartentypen, exakte Rückrekonstruktion der V9-Logik, JavaScript-Syntax von Loader, Katalog und Spiellogik. Nicht geprüft: Browser, Firebase, Render und Multiplayer.

Hinweis: Die übrigen 34+ Logikteile sind weiterhin technisch geteilt und noch keine unabhängigen Funktionsmodule. V10 nur als Entwicklungsfassung verwenden.
