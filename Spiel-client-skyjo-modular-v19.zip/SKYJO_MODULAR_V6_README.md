# SKYJO modular V6 – gemeinsame Spiellogik

- Die beiden normalen SKYJO-Einstiegsseiten verwenden jetzt **dieselben 34 JavaScript-Teildateien** und **denselben Loader**.
- Der zweite Einstiegspunkt `Skyjo/Skyjo/skyjo_action.html` bleibt erhalten; er referenziert `../skyjo_action-loader.js`.
- Die CSS-Dateien und HTML-Strukturen der beiden Varianten bleiben unverändert, um keine relativen Bild- und Profilpfade umzulenken.
- 35 redundante Dateien entfernt; etwa 328 KB weniger Quellmaterial.
- Zusammengesetzter JavaScript-Quelltext weiterhin bytegenau identisch (SHA-256 geprüft).
- Die ursprünglichen 34 JavaScript-Teile sind noch **keine fachlich unabhängigen Module**.
- Browser- und Online-Multiplayer-Test steht aus; nicht produktiv deployen.
- GitHub/Render unverändert.
