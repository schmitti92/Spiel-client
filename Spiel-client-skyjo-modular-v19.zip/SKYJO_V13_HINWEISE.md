# SKYJO Action V13 – gezielte Regressionstests

## Änderungen
- Neuer Test `tests/skyjo-v13-scenarios.test.cjs` für fünf Grenzfälle: Dieb ohne Ziel, drei Karten bei leerem Stapel, Reaktivierung ohne fremde Ablagekarte, Meteorit mit teils verteidigten Gegnern und mit vollständig verteidigten Gegnern.
- Manifest-Version und Loader-Versionsprüfung auf 13 angehoben.
- Bestehende V12-Tests auf Manifest 13 angepasst; Spielregeln, Kartenlogik und Serverkommunikation **nicht verändert**.

## Ausführen
- `node tests/skyjo-v13-scenarios.test.cjs`
- `node tests/skyjo-v12-abilities.test.cjs`

## Grenzen
Die Tests prüfen echte isolierte Funktionen mit simuliertem Spielzustand. Kein vollständiger Browser-/Multiplayer-Test; keine Freigabe für Produktion. Der Loader lädt weiterhin alle 35 Teile und setzt sie zu einem Blob-Skript zusammen; CSP-Kompatibilität muss separat geprüft werden.
