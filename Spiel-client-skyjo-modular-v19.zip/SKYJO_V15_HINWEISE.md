# SKYJO V15 – Online-Zustandsübernahme und Versionsschutz

Neue Tests für `applyCloudDoc`, `scheduleCloudApply` und `flushDeferredCloudApply`: alte Revisionen verwerfen, neue Spielstände übernehmen, Zustandsänderungen während Animationen zurückstellen und danach nachziehen. Bestehende Spiel- und Serverlogik unverändert. Keine echten Netzwerk-/Multiplayer-Tests.
