# SKYJO V8 – Testfassung

- Comic-Beta- und Comic-Preview-Dateien entfernt. **Die SKYJO-Action-Spezialkarten bleiben erhalten.**
- In der Hauptspiellogik nur das Standard-Spielfeld zur Auswahl; frühere gespeicherte Themes werden auf Standard zurückgeführt.
- SKYJO-Startseite zeigt nur Klassisch.
- Verschachtelter SKYJO-Pfad leitet auf die Hauptseite weiter, statt relative CSS/JS-Pfade falsch aufzulösen.
- Die 34 JavaScript-Teildateien werden weiterhin per Blob-Loader zusammengesetzt. Das ist **noch keine endgültige Funktionsmodularisierung** und kann bei restriktiven Content-Security-Policies scheitern.
- `firebase-config.js` ist im Ausgangspaket nicht vorhanden; der Verweis wurde nicht blind entfernt, da bestehende Integration ungeklärt ist.
- Noch keine echten Browser-/Multiplayer-Tests; produktive GitHub-/Render-Version unverändert.
