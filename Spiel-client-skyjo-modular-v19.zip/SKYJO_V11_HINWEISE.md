# SKYJO V11 – Lade- und Integritätsabsicherung

- 35 Teile bleiben bytegenau wie V10; neun Spezialkartendefinitionen unverändert.
- Loader lädt fehlgeschlagene Anfragen bis zu dreimal und zeigt einen Wiederholen-Button.
- SHA-256-Prüfung aller Teile vor Ausführung.
- Entfernt nur den nicht vorhandenen `../firebase-config.js`-Scriptverweis der SKYJO-Seite. Die bestehende Profilanmeldung (`profile-config.js`, `profile-auth.js`, `profile-core.js`) bleibt erhalten.
- Browser-, Firebase- und Multiplayer-Funktionstests stehen aus; nicht produktiv freigeben.
