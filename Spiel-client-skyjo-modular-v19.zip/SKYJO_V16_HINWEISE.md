# SKYJO V16 – Test des Zugablaufs

Neue isolierte Tests mit drei simulierten Spielern: Raumstruktur, Hostrechte, Zugberechtigung, Wechsel zum nächsten Spieler, Extrazug, Ablage gehaltener Reaktionen und Abschlussrunden-Warteschlange. Die Spiel- und Serverlogik ist gegenüber V15 unverändert. **Kein echter Browser-/Netzwerk-Multiplayer-Test.**
