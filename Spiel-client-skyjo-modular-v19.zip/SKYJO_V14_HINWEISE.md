# SKYJO Action V14 – Zustands- und Multiplayer-Schutztests

Neue Regressionstests prüfen: einmaligen Verbrauch von Verteidigung, Übertragung in den Aktionsablage-Stapel, ungültige Spieler, veraltete Kartenauswahl und das Verbot eines Tauschs auf einem nicht aktiven Online-Gerät.

Keine Änderung der Spielregeln oder des Render-Servers. Manifest und Loader auf V14 angepasst. Die Tests simulieren ausgewählte Zustände; sie ersetzen keine echten Browser- und Multiplayer-Tests.

Aufruf: `node tests/skyjo-v14-state-sync.test.cjs`.
