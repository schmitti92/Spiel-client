# SKYJO V18 – HTTP-Integrationstest (lokal)

Neu: Ein lokaler HTTP-Server liefert die tatsächliche SKYJO-HTML-Seite, deren verlinkte Dateien, das Modulmanifest und alle 35 Logikteile aus. Der Test lädt die Ressourcen über HTTP, vergleicht SHA-256-Prüfsummen und prüft, ob sich der zusammengesetzte Code parsen lässt. Dazu werden die bisherigen automatisierten SKYJO-Tests erneut ausgeführt.

**Grenze:** Dies ist kein Test mit Render, Firebase, Browserinteraktionen oder mehreren echten Geräten. Ein echter Raumbeitritt, Spielzug und Spielende wurden damit nicht Ende-zu-Ende bestätigt. Der Server wurde nicht geändert. Produktive GitHub-/Render-Deployments wurden nicht angefasst.

Ausführen: `node tests/skyjo-v18-http-smoke.test.cjs` und `node tests/skyjo-v18-contract.test.cjs`.
