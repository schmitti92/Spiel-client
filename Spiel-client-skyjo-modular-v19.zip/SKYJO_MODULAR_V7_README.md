# SKYJO Modular V7 – überprüfbare Grundlage für echte Funktionsmodule

## Neu
- `Skyjo/skyjo-module-audit.json`: SHA-256-Prüfsummen aller 68 JS-Teildateien und eine Funktionsübersicht als Einstieg für die weitere Refaktorierung.
- `Skyjo/verify_skyjo_modules.py`: prüft alle Dateien auf Vollständigkeit, unveränderten Inhalt und die Syntax des rekonstruierten JavaScripts.
- Original-Spiellogik, Loader, HTML, CSS und Serververbindungen bleiben gegenüber V6 unverändert.

## Prüfung
`python3 Skyjo/verify_skyjo_modules.py`

## Wichtig
Die 34 Teile je Variante sind weiterhin keine unabhängigen ES-Module. Sie werden zur Laufzeit zusammengefügt. Eine funktionale Auslagerung von Spezialfähigkeiten ist erst nach Ermittlung aller gemeinsamen Zustände und Browser-/Mehrspielertests sicher. V7 ist nicht produktiv getestet; GitHub und Render sind unverändert.
