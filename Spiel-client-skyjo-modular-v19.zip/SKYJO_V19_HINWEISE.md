# SKYJO V19 – Browser-Test

Ein ausführbarer Playwright/Chromium-Browsertest wurde hinzugefügt: `python tests/skyjo-v19-browser-smoke.py`. Er startet einen lokalen HTTP-Server, öffnet die echte SKYJO-Seite und prüft Start, sichtbaren App-Inhalt sowie JavaScript-Fehler.

**In dieser Ausführungsumgebung blockiert Chromium die lokale Navigation (`ERR_BLOCKED_BY_ADMINISTRATOR`). Der Browsertest ist daher NICHT bestanden und die Darstellung im Browser NICHT verifiziert.** Das bedeutet nicht automatisch einen Fehler im Spiel. Siehe `SKYJO_V19_PRUEFBERICHT.json`.

Die eigentliche SKYJO-Spiellogik und Serverkommunikation wurden nicht geändert. Nur Loader-/Manifest-Versionsnummer und Testskript sind neu. GitHub/Render wurden nicht geändert.
