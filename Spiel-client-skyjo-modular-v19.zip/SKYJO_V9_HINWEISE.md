# SKYJO V9 – Testfassung

Die Auswahl für nicht existierende Spielbretter wurde aus dem Host-Setup, der Online-Lobby, den Darstellungsoptionen und der oberen Leiste entfernt. Die Informationsansicht `showBoardMenu` bleibt als Kompatibilitätsfunktion erhalten. Die Host-/Server-Datenfelder für Brett-Einstellungen bleiben unverändert, damit alte Online-Räume kompatibel bleiben.

Die neun Aktionsfähigkeiten, Spielzüge und Online-Protokolle wurden nicht verändert. Die JavaScript-Dateien sind weiterhin technische Fragmente einer gemeinsamen IIFE, **keine unabhängig importierbaren Funktionsmodule**. Der bisherige Blob-Loader bleibt bestehen. Browser- und Multiplayer-Tests stehen aus. Nicht auf Produktion deployen, bevor diese bestanden sind.
