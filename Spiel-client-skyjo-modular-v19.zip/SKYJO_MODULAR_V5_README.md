# SKYJO modular V5 – Teststand

- Drei SKYJO-Einstiegspunkte: Skyjo/skyjo_action.html, Skyjo/Skyjo/skyjo_action.html, Skyjo/skyjo_action_comic_beta.html.
- JavaScript-Quelltext **bytegenau unverändert**, jetzt in max. 10.000 Byte große Dateien aufgeteilt.
- Loader setzt die Teile in Originalreihenfolge zusammen und führt sie als ein Skript aus; das ist **keine echte fachliche Modulisierung**.
- CSS-Aufteilung aus V4 unverändert.
- Integritätsprüfung: `python3 tests/check_skyjo_modular.py` (Node.js für Syntaxprüfung benötigt).
- Browser, CORS, Online-Multiplayer, Sonderfähigkeiten und Mobilgeräte **noch nicht getestet**. GitHub/Render unverändert.
- Nicht produktiv deployen, bevor mindestens zwei Geräte gemeinsam getestet wurden.
